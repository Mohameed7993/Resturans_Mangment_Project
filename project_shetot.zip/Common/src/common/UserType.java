package common;

public enum UserType {
Customer,BranchManager,CEO,Supplier, 
}
