package common;

public enum MessageType {
	login, connect, disconnect,scan,ViewResturants,ViewTybeMeallist,ViewDishList,
	ViewSelctionsList,w4cCard,bussinessAccounts,OrdersListToDataBase,itemsListtoDataBase
	
}
