package common;

public enum MessageType {
	login, connect, disconnect,scan,ViewResturants,
	ViewTybeMeallist,ViewDishList,
	ViewSelctionsList,w4cCard,bussinessAccounts,
	OrdersListToDataBase,itemsListtoDataBase,
	OrderListBuild, ItemList, GetOrder,
	updateCelling, OrderListBuildEdit,
	RefundAdd, getRefund, logout, editDishName, getDishesFromResturant,
	additem, getOptionalIngredients, AddOption, UpdateItem, GetResturantOrders, 
	approveOrder, GetOrdersDishes, GetWaitingOrders, GetEmployees, AddEmployer,
	DeleteOption, UpdateStatus, ApproveaccountB, deleteDish, updateRegund, getCustomer;
	
}