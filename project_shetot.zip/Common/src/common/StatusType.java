package common;

public enum StatusType {
Ready,UnReady
}
