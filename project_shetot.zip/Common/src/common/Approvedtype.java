package common;

public enum Approvedtype {
Approved,UnApproved
}
