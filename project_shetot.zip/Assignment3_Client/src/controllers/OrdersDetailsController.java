package controllers;

import java.net.URL;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Approvedtype;
import common.ItemList;
import common.Message;
import common.MessageType;

import common.OrdersList;
import common.StatusType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class OrdersDetailsController implements Initializable {
	public static OrdersList orders=null;
	public static Integer CountParticipants;
	
	
	public LocalDateTime ArrivalTime;
	public static String orderTime;
	public static Integer orderPackageNumber;
	public static String time;
	
	
	public static ArrayList<ItemList> Items=new ArrayList<>();

	public static ItemList AddItem;
	public int i=1;
	
    public int orderPrice;
    public double tempPrice;
    @FXML
    private ImageView image;

    @FXML
    private Button BackButton;

    @FXML
    private Button ConfirmButton;

    @FXML
    private Text Orderdetailstxt;

    @FXML
    private Text resturantnametxt;

    @FXML
    private Text resturantfield;

    @FXML
    private Text reqdatetxt;

    @FXML
    private Text deleiverytxt;

    @FXML
    private Text totalpricetxt;

    @FXML
    private Text totalmesstxt;

    @FXML
    private Text Citytxt;
    
    @FXML
    private Text addresstxt;

    @FXML
    private Text streettxt;

    @FXML
    private Text HouseNumbertxt;

    @FXML
    private Text requesteddatefield;

    @FXML
    private Text delevfield;

    @FXML
    private Text totalpricefield;

    @FXML
    private Text cityfield;

    @FXML
    private Text streetfield;

    @FXML
    private Text huosefiled;

    @FXML
    private Text credittxt;

    @FXML
    private Text empnametxt;

    @FXML
    private Text empidtxt;

    @FXML
    private Text creditfield;

    @FXML
    private Text empnamefield;

    @FXML
    private Text empidfield;
    

    @FXML
    void BackButtonAction(ActionEvent event) {
    	
    	 ((Node) event.getSource()).getScene().getWindow().hide();// get stage
    	PaymentMethodController.IsDeleiveryShared=false;
    
    }

    @FXML
    void ConfirmButtonAction(ActionEvent event) {
    	System.out.println(1);
    	time=PaymentMethodController.dtf.format(PaymentMethodController.now);
    	if(PaymentMethodController.flagDate==1)
    	orderTime=(time);
    	else 
    		orderTime=PaymentMethodController.Time;
    	
    	orderPackageNumber=null;
    	if(!PaymentMethodController.DeleiveryType.equals("TakeAway")) {
    		orders= new OrdersList(ChatClient.userlogged.getId(),ChooseResturantController.resturant.getResturantName(),orderPackageNumber,orderTime
    				,time,String.valueOf(orderPrice),PaymentMethodController.address.toString(),PaymentMethodController.DeleiveryType
    				,"UnReady","0","UnApproved");
    		System.out.println(1);
    	}
    	else {
    		orders= new OrdersList(ChatClient.userlogged.getId(),ChooseResturantController.resturant.getResturantName(),orderPackageNumber,orderTime
    				,time,String.valueOf(orderPrice),"NoAddress",PaymentMethodController.DeleiveryType
    				,"UnReady","0","UnApproved");
    		System.out.println(1);
    	}
    	System.out.println(1);
    	ClientUI.chat.accept(new Message(MessageType.OrdersListToDataBase, orders.getCustomer_ID()+" "+orders.getResturant()+" "+orders.getOrderPackageNumber()
    	+" "+orders.getRequestDate()+" "+orders.getOrderedDate()+" "+orders.getTotalPrice()+" "+orders.getAddress()+" "+orders.getDeleiveryService()
    	+" "+orders.getStatus()+" "+orders.getArrivalTime()+" "+orders.getApprovalRecieving()));
    	System.out.println(1);
    	ClientUI.chat.accept(new Message(MessageType.GetOrder,ChatClient.userlogged.getId()));
    	System.out.println(1);

     	for(int i=0;i<ItemDetailsController.itemList.size();i++)
    	{
     		System.out.println(1);
    	     if(OptionalSelectionController.sel.size()!=0) {
    		          AddItem=new ItemList(ItemDetailsController.itemList.get(i).getTypeMeal() , ItemDetailsController.itemList.get(i).getDishes(),
    				  ItemDetailsController.itemList.get(i).getExtras().toString().replaceAll(" ",""), ItemDetailsController.itemList.get(i).getQuantity()
    				  ,ItemDetailsController.itemList.get(i).getTotalPrice(),ChatClient.order2.getOrderPackageNumber());
    		   Items.add(AddItem);
    	       }
    	     else {
    	    	 System.out.println(1);
    		         AddItem=new ItemList(ItemDetailsController.itemList.get(i).getTypeMeal() , ItemDetailsController.itemList.get(i).getDishes(),
    				"NoExtra", ItemDetailsController.itemList.get(i).getQuantity()
   				   ,ItemDetailsController.itemList.get(i).getTotalPrice(),ChatClient.order2.getOrderPackageNumber());
    	 	Items.add(AddItem);
    	        }  
    }
    	
    	
    	for(int i=0;i<Items.size();i++)
    	{
    		System.out.println(2);
    		ClientUI.chat.accept(new Message(MessageType.itemsListtoDataBase, Items.get(i).getTheMeal()+" "+ Items.get(i).getTheDish()+" "+
    		Items.get(i).getIngredient()+" "+ Items.get(i).getQuantity()+" "+ Items.get(i).getPrice()+" "+ Items.get(i).getPackageID()));
    		System.out.println(3);
    	}
    	

    	
    	ItemDetailsController.itemList.clear();
    	Items.clear();
    	
    	System.out.println(4);
    if(PaymentMethodController.accountpayment.equals("buissiness")) {
		String wallet=(PaymentMethodController.Wallet);
		int orederPrice=Integer.valueOf(orders.getTotalPrice());
		int x=Integer.valueOf(wallet)-orderPrice;
		wallet=String.valueOf(x);
		System.out.println(5);
		ClientUI.chat.accept(new Message(MessageType.updateCelling,wallet+" "+ChatClient.w4ccard.getW4cCode()));
		System.out.println(6);
    }
    
		PaymentMethodController.address=null;
		PaymentMethodController.Time=null;
    	
		

		if(PaymentMethodController.DeleiveryType.equals("SharedDeleivery"))
		{
			System.out.println(6);
			     if(PaymentMethodController.Participants_Number==1)
			       {
			    	 PaymentMethodController.IsDeleiveryShared=false;
				 	 PaymentMethodController.DeleiveryType="null";
				 	 PaymentMethodController.flagDate=2;
				 ((Node) event.getSource()).getScene().getWindow().hide();// get stage
			    	CustomerHomeController AFrame=new CustomerHomeController();
					try {
						AFrame.start(CustomerHomeController.stage1);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			else
			{
				System.out.println(7);
				if(i<PaymentMethodController.Participants_Number)
				{
					

					PaymentMethodController.Temp=PaymentMethodController.Temp+1;
					
					if(PaymentMethodController.Temp==PaymentMethodController.Participants_Number) {
						System.out.println(8);
						PaymentMethodController.IsDeleiveryShared=false;
					 	 PaymentMethodController.DeleiveryType="null";
					 	 PaymentMethodController.flagDate=2;
						 ((Node) event.getSource()).getScene().getWindow().hide();// get stage
					    	CustomerHomeController AFrame=new CustomerHomeController();
							try {
								AFrame.start(CustomerHomeController.stage1);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					}else {
						((Node) event.getSource()).getScene().getWindow().hide();// get stage
				    	TybeMealController AFrame=new TybeMealController();
						try {
							AFrame.start(CustomerHomeController.stage1);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						i++;
					}
						 
							
				}
			}
			
		}
		else {
			
			PaymentMethodController.IsDeleiveryShared=false;
		 	 PaymentMethodController.DeleiveryType="null";
		 	 PaymentMethodController.flagDate=2;
			 ((Node) event.getSource()).getScene().getWindow().hide();// get stage
		    	CustomerHomeController AFrame=new CustomerHomeController();
				try {
					AFrame.start(CustomerHomeController.stage1);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
    	

    	
 
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		if(PaymentMethodController.accountpayment.equals("private")) {
			empidtxt.setVisible(false);
			empidfield.setVisible(false);
			empnamefield.setVisible(false);
			empnametxt.setVisible(false);
			creditfield.setVisible(true);
		creditfield.setText(ChatClient.w4ccard.getCreditCardNumber());
		}else {
			credittxt.setVisible(false);
			creditfield.setVisible(false);
			empidfield.setText(ChatClient.bussiness.getEmployerId());
			empnamefield.setText(ChatClient.bussiness.getEmployerName());
		}
			
		resturantfield.setText(ChooseResturantController.resturant.getResturantName());
		

		if(PaymentMethodController.flagDate==0)
		{
		requesteddatefield.setText(PaymentMethodController.Time);
		}
		else requesteddatefield.setText("now");
		
		
		delevfield.setText(PaymentMethodController.DeleiveryType);
		orderPrice=ItemDetailsController.TotalPrice+PaymentMethodController.pricedeleivery;
		
		if(PaymentMethodController.flagDate==0) {//0->after two hour,1-> now
			tempPrice=(ItemDetailsController.TotalPrice+PaymentMethodController.pricedeleivery)*0.1;
			orderPrice=orderPrice-(int)tempPrice;
		}
		totalpricefield.setText(String.valueOf(orderPrice));
		
		if(PaymentMethodController.DeleiveryType.equals("TakeAway")) {
			addresstxt.setVisible(false);
			Citytxt.setVisible(false);
			streettxt.setVisible(false);
			HouseNumbertxt.setVisible(false);
			cityfield.setVisible(false);
			streetfield.setVisible(false);
			huosefiled.setVisible(false);
		}
		else {
			if(PaymentMethodController.address!=null) {
			cityfield.setText(PaymentMethodController.address.getCity());
			streetfield.setText(PaymentMethodController.address.getStreet());
			huosefiled.setText(PaymentMethodController.address.getHouseNumber());
			}
		}
		
			
		
		
		
	}
	
	public void start(Stage stage)  throws Exception {
		// TODO Auto-generated method stub
		
		Parent root = FXMLLoader.load(getClass().getResource("/View/OrdersDetails.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("Payment");
		stage.setScene(scene);

		stage.show();
	}

}
